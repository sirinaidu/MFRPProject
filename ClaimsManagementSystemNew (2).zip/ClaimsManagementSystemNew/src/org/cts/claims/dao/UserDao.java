package org.cts.claims.dao;

public interface UserDao {
	
	String validateUser(String uname,String pwd);

}
